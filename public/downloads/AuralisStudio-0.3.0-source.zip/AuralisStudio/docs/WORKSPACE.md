# Auralis Studio 0.3 workspace

The plain HTML/CSS/JavaScript workstation now has a compact desktop menu, contextual command ribbons, open-document tabs, resizable side panels, a docked or floating tool window, and persistent transport. The layout follows the editing hierarchy in the WaveLab Pro 13 manual while using Auralis names, icons, styling and independently implemented code. This is a functional subset, not complete UI or feature parity.

## Finding the controls

| Workspace area | Available workflows |
|---|---|
| Audio Editor | View, Edit, Insert, Process, Correction, Spectrum, Analyze and Render ribbons |
| Audio Montage | View, Edit, Insert, Process, Clip, Fade, Envelope, Analyze and Render ribbons |
| Left panel | File search/import, numeric clip inspector, track mute/solo/gain/pan/color, timed comments |
| Right master section | Equalizer with computed response curve, compressor, limiter release/ceiling, output gain, bypass, presets, native processing, delivery and monitoring |
| Tool window | Meters, editable markers, clip list, fades, interactive volume envelope, undo history, metadata, delivery and collaboration |
| Command search | Ctrl/Cmd+K; search by action, category or workflow; unavailable commands explain their prerequisites |
| Workspace menu | Editing, mastering, montage and restoration layouts; panel visibility; preferences and keyboard shortcuts |
| Transport | Play/pause, Stop, record/finish recording, previous marker, beginning/end, selection playback, loop, numeric cursor position, render rate and position format |

Layout and keyboard preferences persist on this device. Divider handles support pointer dragging and arrow keys. The tool window can float within the browser viewport, move by its header and resize from its edge. Layout presets dock it again. Document tabs represent clips in one project; closing a tab hides it without removing its audio. Selecting its file reopens it.

## Editing

Audio Editor copies actual selected PCM, or the entire clip when no range is selected. Paste replaces the selected range or inserts at the cursor, resamples the clipboard to the destination sample rate, adapts mono/stereo channels and creates an immutable derived source. Montage Copy/Paste duplicates clip references. Original sources remain available, including when a copied derived clip is pasted after Undo.

The clip inspector exposes name, track, timeline position, source offset, duration, gain, fades and mute. Exact values accept sample-precise fractions. Clip Properties also exposes numeric volume-envelope points. In the Envelope tool, click to add, drag to move and right-click to remove points. The keyboard alternative is Add point at cursor plus numeric properties. Fades and crossfades are linear.

Selections can be entered as timecode, seconds or samples. Dragging supports snapping to markers and clip boundaries, with Alt bypass. Horizontal zoom, sample zoom, amplitude zoom, overview panning and cursor follow are separate controls. Montage track scrolling keeps track heights usable. Audio Editor auditions the selected source clip; Montage auditions the arrangement. Export dialogs expose their own scope.

Numeric knob entry, keyboard adjustment, dial dragging and range sliders drive real engine parameters. Dial gestures create one undo step; double-click resets to the configured default. Changes to master settings mark previous output measurements as stale.

## Spectral and analysis tools

Spectrum opens a worker-generated spectrogram with rectangular time/frequency selection. Drag a rectangle, then choose attenuation, gate or interpolation; fractional frequency bounds are preserved. Correction exposes noise-profile capture, denoising, declicking, predictive healing, pitch detection and sustained-note correction. Processing dialogs show only parameters relevant to the selected operation.

The spectrogram covers up to 30 seconds of the visible source region; zoom and scroll to inspect other regions. Spectrogram generation is CPU FFT work in an audio worker. The independent WebGPU renderer draws waveform primitives and selection overlays; it does not generate the spectral image itself.

Peak meters, spectrum and phasescope update during playback. Integrated loudness and delivery measurements come from analysis passes, with the measured source/clip/range/output identified in the UI. Analyze selection, Analyze clip, Analyze master and verified delivery have distinct scopes.

## Current parity boundaries

- One project with clip-based document tabs; no simultaneous independent project/file-tab groups, native multi-window docking or WaveLab workspace preset import.
- Fixed equalizer/compressor/limiter master chain. No arbitrary insert/reorder routing, native plug-in editor windows, full playback-processing/resampling/speaker-configuration chain or surround monitor controller.
- One selected clip at a time, stereo tracks, linear fades/crossfades and gain automation. No multiselection grouping, ripple editing, tempo grid, musical time signatures, video timeline or surround automation.
- Rectangular spectral selection; no lasso, brush, magic wand, additive/subtractive masks, spectral clipboard or commercial restoration-suite equivalence.
- Streamed waveform peaks remain summaries at deep zoom. Sample zoom does not fetch and display individual streamed PCM samples. Ruler labels remain seconds/minutes even when numeric position fields use samples.
- WAV-centered rendering plus the existing CD/CUE/DDP and ADM workflows. No new MP3/FLAC encoder, optical-disc burning, licensed Dolby Atmos tools or arbitrary third-party plug-in qualification.
- Collaboration merges saves and supports retained versions, comments, roles and conflict review; it is not simultaneous gesture-level audio co-editing. Existing storage, streaming, native companion, security and qualification boundaries still apply.

See [capabilities](CAPABILITIES.md) and [verification](VERIFICATION.md) for algorithm, native platform and production limits.

## Reference workflow documentation

- [WaveLab workspace](https://www.steinberg.help/r/wavelab-pro/13.0/en/wavelab/topics/workspace_window/workspace_window_r.html)
- [Workspace layout](https://www.steinberg.help/r/wavelab-pro/13.0/en/wavelab/topics/customizing/workspace_layout_c.html)
- [Audio Editor Edit tab](https://www.steinberg.help/r/wavelab-pro/13.0/en/wavelab/topics/audio_files_editing/audio_file_editing_tab_edit_r.html)
- [Spectrum tab](https://www.steinberg.help/r/wavelab-pro/13.0/en/wavelab/topics/audio_files_editing/tab_spectrum_r.html)
- [Audio Montage window](https://www.steinberg.help/r/wavelab-pro/13.0/en/wavelab/topics/audio_montage/audio_montage_window_c.html)
- [Master Section](https://www.steinberg.help/r/wavelab-pro/13.0/en/wavelab/topics/master_section/master_section_window_r.html)
