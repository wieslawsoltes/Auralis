import { validateProject } from './validation.js';
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const plain = x => x !== null && typeof x === 'object' && !Array.isArray(x);
const groups = { clips: ['assetId', 'offset', 'duration', 'fadeIn', 'fadeOut', 'automation'], assets: ['sampleRate', 'duration', 'demo'] };
/** Server loads base from retained history. Conflicts are atomic, keyed by stable entity IDs. */
export function mergeProject(base, incoming, head, { choices = {}, tombstones = [] } = {}) {
    const conflicts = [];
    const deleted = new Set(tombstones.map(t => t.entity_type + ':' + t.entity_id));
    function merge(b, l, r, path) { if (equal(l, b))
        return structuredClone(r); if (equal(r, b) || equal(l, r))
        return structuredClone(l); if (!path.endsWith('.$content') && plain(b) && plain(l) && plain(r)) {
        const out = {};
        for (const k of new Set([...Object.keys(b), ...Object.keys(l), ...Object.keys(r)])) {
            const v = merge(b[k], l[k], r[k], path + '.' + k);
            if (v !== undefined)
                out[k] = v;
        }
        return out;
    } const decision = choices[path]; if (decision === 'incoming')
        return structuredClone(l); if (decision === 'head')
        return structuredClone(r); conflicts.push({ path, kind: l === undefined ? 'delete/edit' : r === undefined ? 'edit/delete' : 'overlap', base: b ?? null, incoming: l ?? null, head: r ?? null }); return structuredClone(r); }
    const out = {};
    for (const k of new Set([...Object.keys(base), ...Object.keys(incoming), ...Object.keys(head)])) {
        if (['id', 'revision', 'tracks', 'clips', 'assets', 'markers'].includes(k))
            continue;
        out[k] = merge(base[k], incoming[k], head[k], k);
    }
    const removed = [];
    for (const type of ['tracks', 'clips', 'assets', 'markers']) {
        const b = new Map(base[type].map(x => [x.id, x])), l = new Map(incoming[type].map(x => [x.id, x])), r = new Map(head[type].map(x => [x.id, x]));
        const ids = [...new Set([...r.keys(), ...l.keys(), ...b.keys()])];
        out[type] = [];
        for (const id of ids) {
            const path = type + '.' + id;
            let v;
            const a = b.get(id), x = l.get(id), y = r.get(id);
            if (!a && x && !y && deleted.has(type + ':' + id)) {
                conflicts.push({ path, kind: 'tombstone', base: null, incoming: x, head: null });
                continue;
            }
            if (a && x && y && groups[type]) {
                const pack = o => { const p = { ...o }, g = {}; for (const k of groups[type]) {
                    g[k] = p[k];
                    delete p[k];
                } p.$content = g; return p; };
                v = merge(pack(a), pack(x), pack(y), path);
                const content = v.$content;
                delete v.$content;
                Object.assign(v, content);
            }
            else
                v = merge(a, x, y, path);
            if (v !== undefined)
                out[type].push(v);
            else if (a)
                removed.push({ entity_type: type, entity_id: id });
        }
    }
    const baseIds = base.tracks.map(t => t.id), liveIds = new Set(out.tracks.map(t => t.id)), order = p => p.tracks.map(t => t.id).filter(id => baseIds.includes(id) && liveIds.has(id));
    const bOrder = baseIds.filter(id => liveIds.has(id)), lOrder = order(incoming), rOrder = order(head);
    let chosen = rOrder;
    if (lOrder.length === bOrder.length && rOrder.length === bOrder.length)
        chosen = merge(bOrder, lOrder, rOrder, 'tracks.$order');
    const rank = new Map(chosen.map((id, i) => [id, i]));
    out.tracks.sort((a, b) => (rank.get(a.id) ?? 1e9) - (rank.get(b.id) ?? 1e9));
    out.id = head.id;
    out.revision = head.revision;
    try {
        validateProject(out);
    }
    catch (e) {
        conflicts.push({ path: 'dependencies', kind: 'invalid-combination', message: e.message });
    }
    return { project: out, conflicts, removed };
}
