# @auralis/audio

Version 0.3.0. ESM module; no runtime dependencies. MIT licensed.

Pack independently with `npm pack` in this directory. See `index.d.ts` for the public API. The complete Auralis Studio repository includes examples, numerical tests, and a capability/validation report.

The pure DSP, WAV and analysis subpaths run in Node and browsers. AudioEngine uses AudioContext and Worker; AudioWorklet is preferred on secure origins, with a main-thread fallback on legacy/insecure origins. Serve worklet.js and worker.js alongside the module. Export uses Float32 planar PCM and a sample-peak limiter, not a certified true-peak limiter.

Version 0.2 adds restoration, WSOLA/pitch processing, streaming PCM providers/render sinks, ADM/CD authoring, streaming loudness/true-peak measurement, and delivery preparation. The master rack retains its sample-peak limiter. Delivery separately applies linked constant gain constrained by measured true peak, then remeasures encoded output and reports peak/loudness target results. EBU fixture passes do not constitute external certification. See the source repository capability matrix for format, memory and qualification limits.
