# Auralis native companion

The browser cannot load VST3, CLAP or AU binaries directly. These offline companions process WAV audio in separate OS processes. They are original host implementations using pinned official interfaces. They are deliberately bounded headless effect hosts, not complete desktop plug-in ecosystems.

## Linux

Requires a C++17 compiler. No CMake or external package installation is required.

```sh
bash native/build.sh
native/build/auralis-clap /absolute/path/effect.clap input.wav output.wav 0=0.5
native/build/auralis-vst3 /absolute/path/Effect.vst3/Contents/x86_64-linux/Effect.so input.wav output.wav 0=0.5
node --test tests/native.test.mjs
```

CLAP parameter values use the plug-in's native parameter range. VST3 values are normalized 0…1. IDs must come from the selected plug-in's parameter documentation. The first audio-effect class is selected. Main input/output topology must match the mono/stereo WAV. Processing is Float32,512-frame blocks with a variable final block. Latency is compensated once; the file retains its original length. Add silence to capture reverb/delay tails. Output is 32-bit float WAV.

To connect the standalone UI, create an explicit allowlist file:

```json
[
  {"id":"master-eq","name":"My mastering EQ","format":"clap","path":"/absolute/path/effect.clap"}
]
```

```sh
AURALIS_PLUGIN_CONFIG=/absolute/path/auralis-plugins.json node server/standalone.mjs
```

Use **Studio tools → Native plug-in companion**. Only IDs in the server's configuration are accepted; the browser cannot supply a library path or executable. The process has a 180-second timeout. The standalone service is loopback-only, validates Host/Origin, and rejects concurrent native jobs. Native plug-ins still execute with your OS account's permissions; process separation is not a malicious-code sandbox. Only load plug-ins you trust.

## macOS AUv 2

```sh
mkdir -p native/build
c++ -std=c++17 -O2 native/au-host.cpp -framework AudioToolbox -framework CoreFoundation -o native/build/auralis-au
native/build/auralis-au SUBT MANU input.wav output.wav
```

Replace SUBT/MANU with the registered four-character subtype/manufacturer. Configure a UI entry with `format:"au"`, `subtype` and `manufacturer`. This source uses synchronous AUv 2 effects. It was not compiled or tested on macOS here. AUv 3, plug-in editors and parameter UI are not implemented.

## DDP 2.0

Obtain cue2ddp and ddpinfo from [their author](http://ddp.andreasruge.de/). The binaries are external dependencies and are not redistributed here.

```sh
AURALIS_CUE2DDP=/absolute/path/cue2ddp \
AURALIS_DDPINFO=/absolute/path/ddpinfo \
node server/standalone.mjs
```

Use **Studio tools → CD / DDP authoring → DDP 2.0**. The server creates a real fileset, verifies it, then returns a ZIP containing the encoder output and verification log. It passes generated CUE and WAV files using fixed names and argument arrays, without a shell. This encoder's CD-Text uses Latin 1. A CUE/WAV ZIP by itself is labeled a CD master, never DDP.

## Licenses and pinned interfaces

- CLAP1.2.10: MIT, Alexandre BIQUE and contributors; upstream commit `a 47f 6badb 49d 948fd 009998f 28309cdab 78979c 9`.
- VST3 pluginterfaces: MIT, Steinberg Media Technologies; upstream commit `4f 547e 8e 102b 47de 4a 8b 8aaf 343c 73b 700786372`.
- Original Auralis host/fixture code: repository MIT license.

Each vendored interface directory retains its own license and upstream commit record. No commercial plug-ins or third-party DDP executables are bundled.
