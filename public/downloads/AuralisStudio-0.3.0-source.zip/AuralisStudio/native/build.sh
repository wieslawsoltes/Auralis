#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
c++ -std=c++17 -O2 -Wall -Wextra -Ivendor/clap/include clap-host.cpp -ldl -o build/auralis-clap
c++ -std=c++17 -O2 -Wall -Wextra -Ivendor/vst3 vst3-host.cpp vendor/vst3/pluginterfaces/base/funknown.cpp -ldl -o build/auralis-vst3
c++ -std=c++17 -O2 -fPIC -shared -Ivendor/clap/include tests/gain-clap.cpp -o build/gain-fixture.clap
c++ -std=c++17 -O2 -fPIC -shared -Ivendor/vst3 tests/gain-vst3.cpp vendor/vst3/pluginterfaces/base/funknown.cpp -o build/gain-fixture.so
