#pragma once
#include "wav.hpp"
#include "pluginterfaces/vst/ivstaudioprocessor.h"
#include "pluginterfaces/vst/ivsthostapplication.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/ivstevents.h"
#include "pluginterfaces/vst/ivstprocesscontext.h"
#include "pluginterfaces/vst/vstspeaker.h"
namespace Steinberg{DEF_CLASS_IID(FUnknown) DEF_CLASS_IID(IPluginBase) DEF_CLASS_IID(IPluginFactory) DEF_CLASS_IID(Vst::IComponent) DEF_CLASS_IID(Vst::IAudioProcessor) DEF_CLASS_IID(Vst::IHostApplication) DEF_CLASS_IID(Vst::IParameterChanges) DEF_CLASS_IID(Vst::IParamValueQueue) DEF_CLASS_IID(Vst::IEventList)}
using namespace Steinberg;using namespace Steinberg::Vst;
#define STATIC_UNKNOWN(Type) tresult PLUGIN_API queryInterface(const TUID iid,void**obj)override{if(FUnknownPrivate::iidEqual(iid,Type::iid)||FUnknownPrivate::iidEqual(iid,FUnknown::iid)){*obj=static_cast<Type*>(this);return kResultOk;}*obj=nullptr;return kNoInterface;} uint32 PLUGIN_API addRef()override{return 1;}uint32 PLUGIN_API release()override{return 1;}
struct HostApplication:IHostApplication{STATIC_UNKNOWN(IHostApplication) tresult PLUGIN_API getName(String128 name)override{const char*s="Auralis Native";int i=0;for(;s[i];i++)name[i]=s[i];name[i]=0;return kResultOk;}tresult PLUGIN_API createInstance(TUID,TUID,void**obj)override{*obj=nullptr;return kNoInterface;}};
struct ParamQueue:IParamValueQueue{ParamID id=0;ParamValue value=0;STATIC_UNKNOWN(IParamValueQueue) ParamID PLUGIN_API getParameterId()override{return id;}int32 PLUGIN_API getPointCount()override{return 1;}tresult PLUGIN_API getPoint(int32 i,int32&at,ParamValue&v)override{if(i)return kInvalidArgument;at=0;v=value;return kResultOk;}tresult PLUGIN_API addPoint(int32,ParamValue,int32&)override{return kNotImplemented;}};
struct Parameters:IParameterChanges{std::vector<ParamQueue>data;STATIC_UNKNOWN(IParameterChanges)int32 PLUGIN_API getParameterCount()override{return data.size();}IParamValueQueue* PLUGIN_API getParameterData(int32 i)override{return i>=0&&i<int(data.size())?&data[i]:nullptr;}IParamValueQueue* PLUGIN_API addParameterData(const ParamID&,int32&)override{return nullptr;}};
struct EmptyEvents:IEventList{STATIC_UNKNOWN(IEventList)int32 PLUGIN_API getEventCount()override{return 0;}tresult PLUGIN_API getEvent(int32,Event&)override{return kInvalidArgument;}tresult PLUGIN_API addEvent(Event&)override{return kResultOk;}};
